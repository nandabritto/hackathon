from django.db import models

# Create your models here.


STATUS_CHOICES = (
    ('reading', 'Reading'),
    ('finished', 'Finished'),
) 

GENRE = (
    ('romance', 'Romance'),
    ('thriller', 'Thriller'), 
    ('terror', 'Terror'), 
    
)
class Book(models.Model):
    title = models.CharField(max_length=100, default='Title')
    # user = models.ForeignKey(
    #     settings.AUTH_USER_MODEL, 
    #     on_delete=models.CASCADE, 
    #     related_name="book"
    # )
    author = models.CharField(max_length=50)
    genre = models.CharField(
        max_length=10,
        choices=GENRE)
    status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES
    )
    
    def __str__(self):
        return self.title