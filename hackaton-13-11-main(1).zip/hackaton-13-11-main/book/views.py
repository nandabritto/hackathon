from django.shortcuts import render
from .models import Book
from django.views.generic import ListView
# Create your views here.

class BookListView(ListView):
    model = Book
    template_name = 'book_list.html'
    context_object_name = "books"

# class BookCreateView(CreateView):
#     model = Book
#     fields = '__all__'
#     template_name = "book_create.html"
#     success_url = reverse_lazy('book_list')

